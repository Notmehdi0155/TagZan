# config.py

BOT_TOKEN = "7301497411:AAEv-ClL65yYqK_jl_aH7k96NDyTsZ0N-Q8"
WEBHOOK_URL = "https://tagzan-1.onrender.com"
ADMIN_IDS = [6387942633, 7189616405, 5459406429, 7143747068]  # شناسه عددی ادمین‌ها
CHANNEL_TAG = "@hotkose | کُصِ داغ " 
PING_INTERVAL = 240  # فاصله زمانی بین پینگ ها به ثانیه
